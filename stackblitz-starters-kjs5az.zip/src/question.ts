export class Question {
  q: string = '';
  ans: string[] = [];
  selectedOptions: boolean[] = [];
  index: number = 0;
}
